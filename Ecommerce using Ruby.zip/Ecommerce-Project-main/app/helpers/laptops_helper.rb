module LaptopsHelper
end
