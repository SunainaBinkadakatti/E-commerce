class Province < ApplicationRecord
  has_many :users
end
