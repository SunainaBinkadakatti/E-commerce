require "test_helper"

class LaptopTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
